import controller as c

c.launch_rocket()
